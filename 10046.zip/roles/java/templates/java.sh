#!/bin/sh
export JAVA_HOME={{ java_home }}
