#!/bin/bash
python ../dotcms_news.py ./args.json
