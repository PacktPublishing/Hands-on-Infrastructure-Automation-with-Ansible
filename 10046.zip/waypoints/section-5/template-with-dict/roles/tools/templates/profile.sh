#!/bin/sh
export {{ item.value.envar }}={{ item.value.dir }}
