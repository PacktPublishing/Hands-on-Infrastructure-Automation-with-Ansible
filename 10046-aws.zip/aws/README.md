# AWS Support Files

This directory contains support files for trying out the examples from
Hands-On Infrastructure Automation with Ansible using virtual machines in
AWS. This includes scripts and Cloud Formation templates to create and
destroy virtual machines in a variety of environments that match the
machines used in the course.

## Prerequsites

To use these, you will need to install and configure the AWS command-line
tools. You will also need to set up the following AWS resources:

1. A VPC and subnet with network 172.31.0.0/24.
2. A security group that allows SSH from your Ansible control machine and
   all connections on the 172.31.0.0/24 network.

You will then need to grab the ID of the subnet and security group and update
the YAML files in this directory. Look for instances of `subnet-XXXXX` and
`sg-XXXXX` and replace accordingly.

You may also need to change the AMI IDs used, especially if you want to use
this in a region other than `us-east-1`.

## Use

The YAML files provide Cloud Formation stacks. Start by setting an environment
variable `STACK_NAME` for the stack you want to work with, e.g.

```
export STACK_NAME=web
```

Then, run `launch.sh` to create the VMs and `check.sh` to monitor progress.
Once the stack is running, run `ips.sh` to get the IP addresses in a form
that can be copied into your `$HOME/.ssh/config` file. This will allow you
to SSH into the machines and also allow you to use an Ansible inventory file
that just uses the bare hostname (e.g. `web01`).

Before running Ansible against the machines, make sure Python is installed
by running `init.sh`.

Finally, when you're finished, don't forget to run `delete.sh` to delete the
stack, ensuring the machines are terminated and you aren't charged for them
any longer.
