#!/bin/bash
MY_DIR="$(cd "${0%/*}" 2>/dev/null; echo "$PWD")"
[[ -n "${STACK_NAME}" ]] || STACK_NAME=dotcms
STACK=$(${MY_DIR}/check.sh)

getip() {
  echo "Host ${1,,}"
  regex="$1[[:space:]]+([0-9\.]*)"
  if [[ $STACK =~ $regex ]]
  then
    echo "  Hostname ${BASH_REMATCH[1]}"
  else
    echo "Hostname unknown"
  fi
}

if [[ $STACK =~ "OUTPUTS" ]]
then
  if [ "${STACK_NAME}" == "dotcms" ]
  then
    getip database01
    getip dotcms01
    getip dotcms02
    getip balancer01
  elif [ "${STACK_NAME}" == "web" ]
  then
    getip web01
    getip web02
    getip web03
    getip web04
  elif [ "${STACK_NAME}" == "server" ]
  then
    getip server01
  elif [ "${STACK_NAME}" == "install" ]
  then
    getip ansible
    getip server01
  elif [ "${STACK_NAME}" == "nfs" ]
  then
    getip nfs01
    getip nfs02
  fi
fi
