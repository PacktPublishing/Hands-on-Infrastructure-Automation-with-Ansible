#!/bin/bash
aws cloudformation describe-stacks
