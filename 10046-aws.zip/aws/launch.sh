#!/bin/bash
MY_DIR="$(cd "${0%/*}" 2>/dev/null; echo "$PWD")"
[[ -n "${STACK_NAME}" ]] || STACK_NAME=dotcms
[[ -n "${TEMPLATE_FILE}" ]] || TEMPLATE_FILE=${STACK_NAME}.yaml
TEMPLATE=file://${MY_DIR}/${TEMPLATE_FILE}
aws cloudformation create-stack --template-body ${TEMPLATE} --stack-name ${STACK_NAME} 
