#!/bin/bash
[[ -n "${STACK_NAME}" ]] || STACK_NAME=dotcms
aws cloudformation delete-stack --stack-name ${STACK_NAME} 
