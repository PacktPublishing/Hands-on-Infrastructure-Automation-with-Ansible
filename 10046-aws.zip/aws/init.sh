#!/bin/bash
[[ -n "${STACK_NAME}" ]] || STACK_NAME=dotcms

function install() {
    ssh -o "StrictHostKeyChecking no" $1 'sudo apt-get update && sudo apt install -y python'
}

export -f install
if [ "${STACK_NAME}" == "dotcms" ]
then
  parallel install ::: database01 dotcms01 dotcms02 balancer01
elif [ "${STACK_NAME}" == "web" ]
then
  parallel install ::: web01 web02 web03 web04
elif [ "${STACK_NAME}" == "server" ]
then
  install server01
elif [ "${STACK_NAME}" == "install" ]
then
  parallel install ::: ansible server01
elif [ "${STACK_NAME}" == "nfs" ]
then
  parallel install ::: nfs01 nfs02
fi
